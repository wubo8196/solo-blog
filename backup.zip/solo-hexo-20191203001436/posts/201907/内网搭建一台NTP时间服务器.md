title: 内网搭建一台NTP时间服务器
date: '2019-07-26 16:57:03'
updated: '2019-07-27 00:40:46'
tags: [Linux, NTP]
permalink: /articles/2019/07/26/1564131423656.html
---
概念：NTP是网络时间协议(**Network Time Protocol**)，它是用来同步网络中各个计算机的时间的协议。

# 资源：

**时间服务器IP:192.168.138.140（ntp server)**

**需要同步时间的服务器：192.168.138.136 (ntp client)**

**linux 系统：CentOS release 6.9**

# 配置ntp server

打开**192.168.138.140机器的 /etc/ntp.conf**

**文件内容如下：**

```
# For more information about this file, see the man pages
# ntp.conf(5), ntp_acc(5), ntp_auth(5), ntp_clock(5), ntp_misc(5), ntp_mon(5).

driftfile /var/lib/ntp/drift

# Permit time synchronization with our time source, but do not
# permit the source to query or modify the service on this system.
restrict default kod nomodify notrap nopeer noquery
restrict -6 default kod nomodify notrap nopeer noquery

# Permit all access over the loopback interface.  This could
# be tightened as well, but to do so would effect some of
# the administrative functions.
restrict 127.0.0.1
restrict -6 ::1

# Hosts on local network are less restricted.
#restrict 192.168.1.0 mask 255.255.255.0 nomodify notrap

# Use public servers from the pool.ntp.org project.
# Please consider joining the pool (http://www.pool.ntp.org/join.html).
server 0.centos.pool.ntp.org iburst
server 1.centos.pool.ntp.org iburst
server 2.centos.pool.ntp.org iburst
server 3.centos.pool.ntp.org iburst

#broadcast 192.168.1.255 autokey        # broadcast server
#broadcastclient                        # broadcast client
#broadcast 224.0.1.1 autokey            # multicast server
#multicastclient 224.0.1.1              # multicast client
#manycastserver 239.255.254.254         # manycast server
#manycastclient 239.255.254.254 autokey # manycast client

# Enable public key cryptography.
#crypto

includefile /etc/ntp/crypto/pw

# Key file containing the keys and key identifiers used when operating
# with symmetric key cryptography.
keys /etc/ntp/keys

# Specify the key identifiers which are trusted.
#trustedkey 4 8 42

# Specify the key identifier to use with the ntpdc utility.
#requestkey 8

# Specify the key identifier to use with the ntpq utility.
#controlkey 8

# Enable writing of statistics records.
#statistics clockstats cryptostats loopstats peerstats

```

# 配置权限

文件中

```
# Permit time synchronization with our time source, but do not
# permit the source to query or modify the service on this system.
restrict default kod nomodify notrap nopeer noquery
restrict -6 default kod nomodify notrap nopeer noquery
```

上面是配置的说明，下面是配置项，这部分的配置是对客户端（需要同步时间的服务器）的请求的处理策略，默认是拒绝。有-6的那一行是对ipv6的配置。可选的配置如下：

```
ignore ：关闭所有的 NTP 联机服务

nomodify：客户端不能修改服务端的时间参数，但客户端可以同步时间。

notrust ：拒绝没有通过认证的客户端机器

noquery ：不提供客户端的时间查询：用户端不能使用ntpq，ntpc等命令来查询ntp服务器

notrap ：不提供trap远端登陆

nopeer ：用于阻止主机尝试与服务器对等，并允许欺诈性服务器控制时钟

kod ： 访问违规时发送 KoD 包。
```

注释掉这两行，配置允许哪些机器可以跟ntp server同步时间

允许所有机器到该机器上同步时间：

```
restrict default nomodify
```

可以配置具体的机器，如：

```
restrict 192.168.138.136 nomodify
```

可以配置网段，如：mask配置子网掩码

```
restrict 192.168.0.0 mask 225.225.225.0 nomodify
```

# 配置时间源

如果可以连接internet，可以配置internet上的时间源，internet上的ntp服务器有很多，可以去搜一下。

如果不能连接internet，则把本机作为时间源即可,配置如下：

```
server 127.127.1.0
fudge 127.127.1.0 stratum 0  #这行是时间服务器的层次。设为0则为顶级，如果要向别的NTP服务器更新时间，请不要把它设为0
```

时间源可以配置多个，先使用最上面的机器，如果这个机器不可用（比如网络连不上），则会逐下使用。

# 启动或重启ntp服务

查看ntp服务运行状态：

```
/etc/init.d/ntpd status
```

启动ntp服务

```
/etc/init.d/ntpd start
```

# 客户端同步时间

使用ntpdate命令同步时间，ntpdate ntp_server_ip

```
ntpdate 192.168.138.140
```

linux系统，客户端的ntp服务不能启动，否则会报如下错误：

```
ntpdate[88383]: the NTP socket is in use , exiting
```

停止ntp服务

```
/etc/init.d/ntpd stop
```

# 定时同步，

方式一 : 可以配置crontab定时任务,如，每小时校验一次时间

```
 *  */1  *  *  * root /usr/sbin/ntpdate 192.168.138.140 >/dev/null 2>&1
```

方式一 : 通过ntp服务同步

客户端安装ntp服务，同上

 

更改"/etc/ntp.conf"，注释掉原有NTP服务器地址，加入"server 时间服务器IP"

```
server 192.168.138.140
#允许时间服务器(上游时间服务器)修改本机时间
restrict 192.168.138.140 nomodify notrap noquery
```

然后，客户机启动ntp服务

# 注意事项：

注意防火墙的问题，如果无法同步，则检查防火墙

出处：https://my.oschina.net/ranxi/blog/2051577